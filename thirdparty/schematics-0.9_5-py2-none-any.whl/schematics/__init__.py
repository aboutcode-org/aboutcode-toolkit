
version_info = ('0', '9', '5')

__version__ = '{0}.{1}-{2}'.format(*version_info)
