license-expression is small utility library to parse, compare simplify and normalize license expressions using bollean logic.It uses boolean.py for parsing and boolean logic.


