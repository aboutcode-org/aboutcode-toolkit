
version_info = ('1', '0', '0')

__version__ = '{0}.{1}-{2}'.format(*version_info)
